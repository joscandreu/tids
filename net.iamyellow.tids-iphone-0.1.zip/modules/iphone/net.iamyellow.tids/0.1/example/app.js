var tids = require('net.iamyellow.tids');

Ti.API.info('OpenUDID is ' + tids.openUDID);
Ti.API.info('The old Titanium\'s ID is ' + tids.oldUDID);