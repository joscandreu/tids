var tids = require('net.iamyellow.tids');

Ti.API.info('OpenUDID is ' + tids.openUDID);